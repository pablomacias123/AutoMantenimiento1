import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
// Necesitarías implementar un controlador de alertas
// import { AlertController } from '../controllers/AlertController'; 

// Datos simulados (en una app real, esto vendría de tu API de Express)
const simulatedAlerts = [
    { id: '1', type: 'warning', title: 'Próximo Cambio Aceite', message: 'Vence en 500 km', action: 'Revisar' },
    { id: '2', type: 'error', title: 'Revisar Pastillas', message: 'Pastillas Vejiga Autoparte (Urgente)', action: 'Comprar' },
    { id: '3', type: 'info', title: 'Verificación Vehicular', message: 'Vence en 30 días', action: 'Agendar Cita' },
    { id: '4', type: 'error', title: 'Revisar Presión de Neumáticos', message: 'Presión baja', action: 'Inflar' },
];

const AlertItem = ({ alert }) => {
    // Define colores basados en el tipo de alerta (como en tu prototipo)
    const colorMap = {
        warning: '#FFC107', // Amarillo
        error: '#D32F2F',   // Rojo
        info: '#2196F3',    // Azul
    };
    
    const iconMap = {
        warning: '⚠️',
        error: '❌',
        info: '🔔',
    };

    return (
        <View style={[styles.alertCard, { borderColor: colorMap[alert.type] }]}>
            <View style={styles.alertIcon}>
                <Text style={{ fontSize: 24 }}>{iconMap[alert.type]}</Text>
            </View>
            <View style={styles.alertContent}>
                <Text style={styles.alertTitle}>{alert.title}</Text>
                <Text style={styles.alertMessage}>{alert.message}</Text>
            </View>
            <TouchableOpacity style={styles.alertActionButton}>
                <Text style={styles.actionText}>{alert.action}</Text>
            </TouchableOpacity>
        </View>
    );
};

const AlertsScreen = () => {
    const [alerts, setAlerts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // En un proyecto real, se llamaría al API GET /api/alerts/user_id
        // fetchAlerts(); 
        
        // Simulación:
        setTimeout(() => {
            setAlerts(simulatedAlerts);
            setLoading(false);
        }, 1000);
    }, []);

    if (loading) {
        return <ActivityIndicator size="large" color="#1E3A3B" style={styles.loadingContainer} />;
    }

    return (
        <View style={styles.container}>
            <Text style={styles.header}>Alertas</Text>
            <FlatList
                data={alerts}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <AlertItem alert={item} />}
                ListEmptyComponent={<Text style={styles.emptyText}>No hay alertas pendientes.</Text>}
            />
            {/* Botón para añadir alerta manual */}
            <TouchableOpacity style={styles.addButton}>
                <Text style={styles.addButtonText}>+</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#fff', padding: 15 },
    loadingContainer: { flex: 1, justifyContent: 'center' },
    header: { fontSize: 28, fontWeight: 'bold', color: '#1E3A3B', marginBottom: 15 },
    alertCard: {
        flexDirection: 'row', alignItems: 'center', backgroundColor: 'white',
        borderRadius: 10, padding: 15, marginBottom: 10, 
        borderLeftWidth: 5, shadowColor: '#000', shadowOpacity: 0.1, elevation: 2,
    },
    alertIcon: { marginRight: 15 },
    alertContent: { flex: 1 },
    alertTitle: { fontSize: 16, fontWeight: 'bold', color: '#1E3A3B' },
    alertMessage: { fontSize: 13, color: 'gray', marginTop: 3 },
    alertActionButton: { marginLeft: 10, paddingHorizontal: 10, paddingVertical: 5, 
        backgroundColor: '#E8E8E8', borderRadius: 5 },
    actionText: { fontSize: 12, fontWeight: 'bold', color: '#1E3A3B' },
    emptyText: { textAlign: 'center', marginTop: 50, fontSize: 18, color: 'gray' },
    addButton: {
        position: 'absolute', right: 30, bottom: 30, width: 60, height: 60,
        borderRadius: 30, backgroundColor: '#4CAF50', justifyContent: 'center', alignItems: 'center',
        elevation: 5,
    },
    addButtonText: { fontSize: 30, color: 'white', lineHeight: 30 },
});

export default AlertsScreen;
