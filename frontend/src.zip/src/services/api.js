import axios from 'axios';

// La IP debe ser la IP de tu red local si estás en un dispositivo físico.
// Si usas el emulador de Android/iOS en la misma máquina, 'localhost' o '10.0.2.2' (Android) pueden funcionar.
// Cuando despliegues la API, esta URL será la dirección en la nube (ej. https://yourapi.com).
const API_BASE_URL = 'http://TU_IP_LOCAL:5000/api'; 

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    // Aquí se configuraría el token de seguridad (ej. 'Authorization': 'Bearer token') [cite: 39]
  },
});

export const carService = {
  // Cómo se manejan los datos recibidos de la API [cite: 51]
  getCars: async () => {
    try {
      const response = await api.get('/cars');
      return response.data; // Devuelve el array de vehículos
    } catch (error) {
      console.error("Error fetching cars:", error);
      throw error;
    }
  },
  
  // Función para agregar un coche
  addCar: async (carData) => {
    // Configuración de la comunicación entre el frontend y la API mediante Axios [cite: 47]
    const response = await api.post('/cars', carData);
    return response.data;
  }
};